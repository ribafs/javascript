// call requestAnimFrame with a parameter of the
// game loop function to call
requestAnimFrame(loopStep);