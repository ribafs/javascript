# बेंचमार्किंग p5.js

बेंचमार्किंग को https://github.com/limzykenneth/p5-benchmark पर उपलब्ध अपने रेपो में स्थानांतरित कर दिया गया है। P5.js के नवीनतम संस्करण के बेंचमार्क परिणाम का एक समग्र दृश्य https://limzykenneth.github.io/p5-benchmark/ पर देखा जा सकता है। अभी भी कार्य प्रगति पर है।