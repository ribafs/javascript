# NoteApp
A simple note taking app

NoteApp is a React app for note taking that uses local storage to save notes.

Some features of the note app include:

1. Adding a note and title.
2. Editing a note.
3. Deleting a note.
4. Deleting all notes.
5. Dark or Light mode. 

It is deployed [here](https://sarahchima.github.io/NoteApp/)
