HTML5 localStrage CRUD sample
=====================

Simple CRUD application using HTML5 localStrage.  
CRUD stands for Create, Read, Update and Delete.

Install
--------
No installation required.  
Put all files in accessible by Web Browser.  
To launch application, open index.html.  

License
--------
[Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/)

Auther
--------
TOKUNO, Hirokazu
