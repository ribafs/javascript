---

# FILTRADO!

Você fez um bom trabalho ao filtrar aquele array.

No próximo desafio vamos ver como acessar os valores de um array.

Execute `javascripting` no console para escolher o próximo desafio.

---
