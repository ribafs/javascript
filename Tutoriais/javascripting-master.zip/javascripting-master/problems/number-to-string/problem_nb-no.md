Noen ganger må du gjøre om et nummer til en string.

I de tilfelle må du bruke `.toString()` metoden. Eksempel:

```js
let nummer = 256
nummer = nummer.toString()
```

## Oppgaven:

Lag en fil som heter `number-to-string.js`.

Definer en variabel med navnet `n` som referer nummeret `128` i den filen.

Kall `.toString()` metoden på den `n` variabelen.

Bruk `console.log()` for å skrive ut resultatet av `.toString()` metoden til skjermen.

Se om programmet ditt er riktig ved å kjøre denne kommandoen:

```bash
javascripting verify number-to-string.js
```
