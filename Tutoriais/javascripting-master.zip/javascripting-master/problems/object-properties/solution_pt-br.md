---

# CORRETO! PIZZA É O ÚNICO ALIMENTO.

Bom trabalho ao acessar esta propriedade.

O próximo desafio se trata de **funções**.

Execute `javascripting` no console para escolher o próximo desafio.

---
