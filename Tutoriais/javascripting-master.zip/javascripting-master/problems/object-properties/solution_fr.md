---

# CORRECT. LA PIZZA Y A QUE ÇA DE VRAI.

Vous avez réussi à accéder à la propriété.

Le prochain défi parlera de **fonctions**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
