---

# CORRECT. PIZZA IS THE ONLY FOOD.

Goed gedaan. Je hebt de eigenschap van het object juist opgevraagd.

De volgende uitdaging gaat over **object keys**.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
