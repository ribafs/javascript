---

# CORRECT.

Je hebt de Object.keys() prototype method correct gebruikt. Onthoud dat je deze method kunt gebruiken als je de keys van object wilt opvragen.

De volgende uitdaging gaat over **functions**.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
