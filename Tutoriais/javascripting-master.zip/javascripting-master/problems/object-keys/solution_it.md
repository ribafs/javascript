---

# CORRETTO.

Ottimo lavoro con il metodo prototipo Object.keys (). Ricorda di usarlo quando devi elencare le chiavi di un oggetto.

La prossima sfida riguarda le ** funzioni **.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
