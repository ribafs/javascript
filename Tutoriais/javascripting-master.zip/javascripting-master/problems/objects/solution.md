---

# PIZZA OBJECT IS A GO.

You successfully created an object!

In the next challenge we will focus on accessing object properties.

Run `javascripting` in the console to choose the next challenge.

---
