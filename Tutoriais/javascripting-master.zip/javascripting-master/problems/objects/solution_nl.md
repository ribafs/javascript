---

# PIZZA OBJECT IS GEMAAKT!

Je hebt met succes een (pizza) object gemaakt!

In de volgende uitdaging gaan we de properties van objecten onder de loep nemen.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
