---

# EL OBJETO PIZZA ES UN ÉXITO.

Creaste correctamente un objeto!

Cómo habrás notado, los valores que pueden tomar las **llaves** de un objeto pueden ser cualquiera: un número, un array, una string, una función e incluso otro objeto.

En el siguiente ejercicio nos concentraremos en acceder a propiedades de los objetos.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
