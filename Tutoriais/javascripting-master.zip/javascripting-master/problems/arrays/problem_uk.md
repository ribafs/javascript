Масивами називають значень. Наприклад:

```js
const pets = ['cat', 'dog', 'rat']
```

### Завдання:

Створіть файл `arrays.js`.

У цьому файлі оголосіть змінну `pizzaToppings`, що міститиме масив, який має складатись із трьох елементів в такому порядку: 'tomato sauce, cheese, pepperoni'.

Скористайтесь `console.log()`, щоб вивести масив `pizzaToppings` в терміналі.

Перевірте вашу відповідь запустивши команду:

```bash
javascripting verify arrays.js
```
