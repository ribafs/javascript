---

# YAY, UN TABLEAU DE PIZZAS !

Vous avez réussi à créer un tableau !

Dans le défi suivant, nous allons explorer le filtrage de tableaux.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
