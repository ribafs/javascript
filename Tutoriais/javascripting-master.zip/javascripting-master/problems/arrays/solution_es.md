---

# SI SEÑOR, UN ARRAY DE PIZZA!

Creaste un array con éxito.

En el siguiente ejercicio continuaremos explorando cómo filtrar arrays.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---

