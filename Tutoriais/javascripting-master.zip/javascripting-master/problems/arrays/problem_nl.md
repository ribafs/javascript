Een array is een lijst met waarden. Hier is een voorbeeld:

```js
const pets = ['cat', 'dog', 'rat']
```

### De uitdaging:

Maak een nieuw bestand met de naam `arrays.js`.

Definieer in het bestand een variabele met de naam `pizzaToppings` die verwijst naar een array met drie strings in deze volgorde: `tomato sauce, cheese, pepperoni`.

Gebruik `console.log()` om de `pizzaToppings` array naar de console te printen.

Controleer of je programma goed werkt met dit commando:

```bash
javascripting verify arrays.js
```
