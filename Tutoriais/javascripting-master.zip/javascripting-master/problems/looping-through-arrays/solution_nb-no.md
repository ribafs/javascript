---

# FLOTT! MANGE KJÆLEDYR!

Nå er alle innslagene i `pets` arrayet i flertall!

I den neste oppgaven går vi fra arrayer til å jobbe med **objekter**.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
