---

# SUCESSO! UM MONTE DE BICHINHOS!

Agora todos os itens no array `pets` estão no plural!

No próximo desafio vamos começar á trabalhar com **objects**.

Execute `javascripting` no console para escolher o próximo desafio.

---
