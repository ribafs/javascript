---

# SUCCES! DIEREN IN MEERVOUD!

Alle items in de `pets` array zijn nu in meervoud!

In de volgende uitdaging gaan we van arrays naar het werken met objecten.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
