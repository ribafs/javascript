---

# CE NOMBRE EST ARRONDI

Ouaip, vous venez d'arrondir le nombre `1.5` vers `2`. Bon boulot !

Dans le prochain défi, nous allons transformer un nombre en chaîne de caractères.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
