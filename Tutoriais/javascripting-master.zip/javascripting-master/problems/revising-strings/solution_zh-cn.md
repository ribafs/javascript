---

# 是的, PIZZA _IS_ WONDERFUL。

干得漂亮，你已经学会了如何使用 `.replace()` 方法！

接下来我们将探索 **numbers**，也就是**数字**。

运行 `javascripting` 命令并选择下一个挑战。

---
