---

# JA, PIZZA _ER_ HERLIG!

Bra jobbet med å bruke `.replace()` metoden!

I neste oppgave skal vi utforske **tall**.

Kjør `javascripting` for å velge neste oppgave

---
