---

# OUI, LA PIZZA C'EST _MERVEILLEUX_.

Bon boulot avec cette méthode `.replace()` !

Nous allons ensuite étudier les **nombres**.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
