---

# CE L'HAI FATTA!

Qualsiasi cosa contenuta tra le parentesi `console.log()` viene stampata sul terminale.

Quindi questo:

```js
console.log('hello')
```

stampa `hello` sul terminal.

Al momento stiamo stampando una **stringa** di caratteri sul terminale: `hello`.

Nella prossima sfida ci occuperemo di apprendere sulle **variabili**.

Esegui `javascripting` nella console per scegliere la prossima sfida.
