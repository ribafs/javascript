---

# HET IS JE GELUKT!

Alles wat je tussen de haakjes van `console.log()` zet, wordt naar de console (terminal) geprint.

Dus dit: 

```js
console.log('hallo')
```

print `hallo` naar de terminal.

Nu printen we nog en **string** bestaande uit characters naar de terminal: `hallo`.

In de volgende uitdaging gaan we leren over **variabele**.

Run `javascripting` in de console om de volgende uitdaging te kiezen.
