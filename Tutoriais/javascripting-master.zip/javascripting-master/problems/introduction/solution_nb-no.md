---

# DU GREIDE DET!

Alt mellom parantesene i `console.log()` skrives ut til skjermen.

Det vil si:

```js
console.log('hello')
```

skriver ut `hello` til skjermen.

For øyeblikket skriver vi ut en **string** av bokstaver til skjermen: `hello`.

I den neste oppgaven skal vi lære om **variabler**.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.
