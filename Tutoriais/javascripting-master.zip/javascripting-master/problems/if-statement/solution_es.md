---

# MAESTRO CONDICIONAL

Lo haz hecho! El string `orange` tiene más de cinco caracteres.

Preparate para practicar **for loops** en el próximo ejercicio!

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
