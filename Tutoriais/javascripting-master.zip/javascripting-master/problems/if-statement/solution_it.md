---

# ESPERTO DEI CONDIZIONALI

Ce l'hai fatta! La stringa `orange` ha più di cinque caratteri.

Preparati ad affrontare i **cicli for** nel prossimo esercizio!

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
