---

# MAÎTRE DES CONDITIONS

Vous avez réussi ! La chaîne de caractères `orange` a plus de cinq caractères.

Préparez vous pour les **boucles for** qui arrivent ensuite !

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
