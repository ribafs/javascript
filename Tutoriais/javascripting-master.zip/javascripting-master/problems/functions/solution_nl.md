---

# WOOO BANANAS

Het is je gelukt! Je hebt een function gemaakt die input ontvangt, deze input verwerkt, en output teruggeeft.

Run `javascripting` in de console om de volgende uitdaging te kiezen.

---
