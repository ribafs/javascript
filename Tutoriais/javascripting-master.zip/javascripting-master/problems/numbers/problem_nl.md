Numbers kunnen hele getallen zijn, zoals `2`, `14`, or `4353`, of getallen met cijfers achter de komma, ook wel 
floats genoemd, zoals `3.14`, `1.5`, of `100.7893423`.

Numbers declareer je altijd zonder aanhalingstekens.

## De uitdaging

Maak een bestand met de naam `numbers.js`.

Maak in dit bestand een variabele met de naam `example` die verwijst naar het hele getal `123456789`.

Gebruik `console.log()` om dit getal naar de console te printen.

Controleer of je programma goed werkt met dit commando:

`javascripting verify numbers.js`
