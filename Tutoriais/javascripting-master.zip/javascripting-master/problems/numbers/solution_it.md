---

# SÌ! NUMERI!

Perfetto, hai definito con successo una variabile con il valore numerico `123456789`.

Nella prossima sfida vedremo come manipolare i numeri.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
