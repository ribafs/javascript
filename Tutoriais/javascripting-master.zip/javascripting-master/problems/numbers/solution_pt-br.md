---

# SIM! NÚMEROS!

Legal, você conseguiu definir uma variável com o valor `123456789`.

No próximo desafio vamos ver como manipular os números.

Execute `javascripting` no console para escolher o próximo desafio.

---
