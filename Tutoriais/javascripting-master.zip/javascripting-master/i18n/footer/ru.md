__Требуется помощь?__ Перечитайте README данного воркшопа: https://github.com/workshopper/javascripting
