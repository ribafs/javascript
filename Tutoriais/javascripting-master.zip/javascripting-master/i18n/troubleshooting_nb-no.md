---
# Huffda, her var det noe som ikke fungerte.
# Men ingen grunn til panikk!
---

## Kontroller din løsning:

`Løsningen
===================`

%solution%

`Ditt forsøk
===================`

%attempt%

`Sammenligning
===================`

%diff%

## Tips til feilsøking:
 * Er du sikker på at du skrev filnavnet riktig? Du kan dobbeltsjekket ved å kjøre ls `%filename%`, hvis du ser: cannot access `%filename%`: No such file or directory burde du lage filen med det navnet / gi filen nytt navn eller bytte til katalogen hvor filen er lagret
 * Sjekk at du ikke ha glemt noen paranteser, det hindrer programmet å bli lest / kompileres
 * Sjekk at du ikke har skrivefeil i stringen som ble skrevet ut
