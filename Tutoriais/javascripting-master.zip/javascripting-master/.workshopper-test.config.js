module.exports = {
  exercisesFolder: 'solutions',
  testFileRegex: 'index.js',
  spaceChar: '-'
}
