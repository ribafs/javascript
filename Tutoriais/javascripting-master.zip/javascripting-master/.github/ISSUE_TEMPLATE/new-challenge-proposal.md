---
name: New Challenge Proposal
about: Propose a new challenge for learning JavaScript
title: ''
labels: ''
assignees: ''

---

**Title**
<!-- Just a title for your challenge -->
<!-- Ex: FUNCTION RETURN VALUES -->

**Goal**
<!-- Ex: Learn how to handle function return values. -->

** Problem **
<!--
  Typically a workshopper problem consist in a description of a javascript
  concept (or feature) that try to teach, a challenge for apply description above
  and lastly a verify instructions
-->
<!-- Ex:
  The result of the function is a value.
  You can get the result of the function as follows:

  const ret = Math.random()

  ** The challenge: **

  Create a file named function-return-value.js.

  Check to see if your program is correct by running this command:

  javascripting verify arrays.js
-->

TODO
