importance: 5

---

# if (a string with zero)

Will `alert` be shown?

```js
if ("0") {
  alert( 'Hello' );
}
```

