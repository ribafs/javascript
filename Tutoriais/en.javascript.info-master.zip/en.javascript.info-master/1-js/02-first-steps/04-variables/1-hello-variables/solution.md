In the code below, each line corresponds to the item in the task list.

```js run
let admin, name; // can declare two variables at once

name = "John";

admin = name;

alert( admin ); // "John"
```

