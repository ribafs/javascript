importance: 4

---

# A simple page

Create a web-page that asks for a name and outputs it.

[demo]
