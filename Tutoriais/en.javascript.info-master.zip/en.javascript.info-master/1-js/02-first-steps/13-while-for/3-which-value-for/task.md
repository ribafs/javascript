importance: 4

---

# Which values get shown by the "for" loop?

For each loop write down which values it is going to show. Then compare with the answer.

Both loops `alert` same values or not?

1. The postfix form:

    ```js
    for (let i = 0; i < 5; i++) alert( i );
    ```
2. The prefix form:

    ```js
    for (let i = 0; i < 5; ++i) alert( i );
    ```
