importance: 3

---

# Last loop value

What is the last value alerted by this code? Why?

```js
let i = 3;

while (i) {
  alert( i-- );
}
```
