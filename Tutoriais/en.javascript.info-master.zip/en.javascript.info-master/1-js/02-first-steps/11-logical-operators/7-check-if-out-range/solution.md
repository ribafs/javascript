The first variant:

```js
if (!(age >= 14 && age <= 90))
```

The second variant:

```js
if (age < 14 || age > 90)
```

