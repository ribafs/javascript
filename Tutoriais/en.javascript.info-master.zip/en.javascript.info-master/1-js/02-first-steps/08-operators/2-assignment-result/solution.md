The answer is:

- `a = 4` (multiplied by 2)
- `x = 5` (calculated as 1 + 4)

