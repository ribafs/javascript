No difference!

In both cases, `return confirm('Did parents allow you?')` executes exactly when the `if` condition is falsy.