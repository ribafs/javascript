function spy(func) {
  // your code
}


