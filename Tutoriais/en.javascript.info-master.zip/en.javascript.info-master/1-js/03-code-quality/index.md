# Code quality

This chapter explains coding practices that we'll use further in the development. 
