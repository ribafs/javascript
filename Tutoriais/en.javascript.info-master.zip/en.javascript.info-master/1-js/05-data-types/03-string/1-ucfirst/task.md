importance: 5

---

# Uppercase the first character

Write a function `ucFirst(str)` that returns the string `str` with the uppercased first character, for instance:

```js
ucFirst("john") == "John";
```

