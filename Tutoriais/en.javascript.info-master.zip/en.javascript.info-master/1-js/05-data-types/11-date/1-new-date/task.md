importance: 5

---

# Create a date

Create a `Date` object for the date: Feb 20, 2012, 3:12am. The time zone is local.

Show it using `alert`.
