export default class Logger {
  log(message) {
    console.log(message);
  }
  error(message) {
    console.error(message);
  }
}