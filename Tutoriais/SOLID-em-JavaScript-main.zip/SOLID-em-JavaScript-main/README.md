# SOLID-em-JavaScript
Exemplos usados na série de vídeos sobre SOLID em JavaScript no canal Brazilian Dev no YouTube


Os arquivos estão enumerados da seguinte forma:

- 1- single_responsibility
- 2- open_closed_principle
- 3- liskov_substitution_principle
- 4- interface_segregation
- 5- dependency_inversion
- 6- NOT_A_SOLID_PRINCIPLE_dependency_injection


Cada exemplo tem o exemplo de VIOLAÇÃO do princípio, e o seu respectivo código refatorado para estar em conformidade com os princípios SOLID.
