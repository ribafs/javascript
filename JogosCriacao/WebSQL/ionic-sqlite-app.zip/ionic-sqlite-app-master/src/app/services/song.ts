export class Song {
    id: number;
    artist_name: string;
    song_name: string;
  }