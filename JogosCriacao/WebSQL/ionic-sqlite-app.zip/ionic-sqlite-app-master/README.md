# ionic-sqlite-app
In this tutorial, we will learn how to create Ionic 4 Angular CRUD application and implement SQLite Native plugin to store the data in the SQLite Database. We will create the Create, Read, Update and Delete operation to manage the data in the database. Moreover, we will also learn to load the dummy data from the sql database file using HttpClient service.

[Ionic 4 SQLite Database CRUD App Example Tutorial](https://www.positronx.io/ionic-sqlite-database-crud-app-example-tutorial/)
