# Cronômetro
### Feito em JavaScript
<p>Cronômetro é um relógio projetado para medir a quantidade de tempo que decorre entre sua ativação e desativação.</p>
<a href="https://freddydanilo.github.io/cronometro-2022/">Clique aqui para testar o projeto</a>
<p></p>
<img src="https://user-images.githubusercontent.com/71949651/197525446-e6d2f179-0724-46cb-b04d-1772cfa3075a.png" />

