if (alasql.options.sqlite) {
}
