# Console functions

* ECHO
* PRINT 