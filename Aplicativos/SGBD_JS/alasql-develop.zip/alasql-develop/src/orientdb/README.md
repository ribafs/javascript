# AlaSQL OrientDB plugin

Supported commands:
```
OSELECT 
CREATE CLASS
CREATE VERTEX
CREATE EDGE
```