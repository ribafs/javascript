# Oracle syntax + pass-thru connector
