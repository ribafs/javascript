# TypeScri[pt definition file

This directory consists of TypeScript definition files