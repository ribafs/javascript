if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 64 - Console', function () {
	it.skip('Console', function (done) {
		done();
	});
});
