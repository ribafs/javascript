if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 88 - AngularJS ng-alasql', function () {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
