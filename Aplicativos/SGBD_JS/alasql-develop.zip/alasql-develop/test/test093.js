if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 93 - COUNT (NON NULL) & COUNT DISTINCT', function () {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
