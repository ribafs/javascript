create table one (a int, b int, c string);
insert into one values (1,1,1), (2,2,2);
alter table one rename column b to bbb;

