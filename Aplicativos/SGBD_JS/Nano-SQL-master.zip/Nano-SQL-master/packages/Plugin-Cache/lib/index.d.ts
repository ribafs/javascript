import { InanoSQLPlugin } from "@nano-sql/core/lib/interfaces";
export declare const RedisIndex: (connectArgs?: any, getClient?: ((redisClient: any) => void) | undefined) => InanoSQLPlugin;
