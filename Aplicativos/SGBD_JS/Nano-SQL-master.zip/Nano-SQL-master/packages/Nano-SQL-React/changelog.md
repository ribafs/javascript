## [1.4.0]
- Components now wait for nanosql to connect to do initial render.

## [1.3.4]
- Updated react import.
- Moved React and NanoSQL to peer dependency.

## [1.3.0]
- Streamlined API, still backwards compatible.
- Updated dependcies

## [1.2.6]
- Updated react typo

## [1.2.3]
- Bumped nanosql dependency version.

## [1.2.2]
- README updates.
- Added error checking.
- Faster looping.

## [1.2.1]
- Might have changed the README again.

## [1.2.0]
- Fixed readme typos.

## [1.1.0]
- Updated readme.
- Small adjustments to the build.

## [1.0.0]
- Initial release