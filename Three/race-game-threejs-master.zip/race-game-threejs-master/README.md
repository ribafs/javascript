# race-game-threejs
A simple race game using three.js

[click here to play](http://noiron.github.io/race-game-threejs/)
